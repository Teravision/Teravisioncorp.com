<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="css/adminstyle.css" rel="stylesheet" />
</head>
<body class="red">
    <div class="admin__navbar">
        <div class="adminnavbar__container">
            <a href="/" id="adminnavbar__logo">Whatsup</a>
            <div class="adminnavbar__toggle">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
            <ul class=adminnavbar__menu>
                <li class="adminnavbar__item">
                    <a href="/" class="adminnavbar__links">Welcome</a>
                </li>
                <li class="navbar__btn">
                    <a href="/" class="button">Logout</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="admin__sidebar">
        <div class="adminsidebar__container">
        <ul class=adminnavbar__menu>
                <li class="adminnavbar__item">
                    <a href="/" class="adminnavbar__links">Welcome</a>
                </li><br>
                <li class="navbar__btn">
                    <a href="/" class="button">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</body>
</html>