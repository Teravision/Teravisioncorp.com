<html>    
    <head>    
        <title>Registration Form</title>    
    </head>    
    <body>    
	
	
	
	
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_sample";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>



        <link href = "registration.css" type = "text/css" rel = "stylesheet" />    
        <h2>Sign Up</h2>    
        <form name = "form1" method = "post" >    
            <div class = "container">    
			
                <div class = "form_group">   
				
                    <label>First Name:</label>    
                    <input type = "text" name = "fname" value = "" required/>  
					
                </div>    
				
											<div class = "form_group">   
											
												<label>Middle Name:</label>    
													<input type = "text" name = "mname" value = "" required />
												
											</div>    
											
											<div class = "form_group">    
											
												<label>Last Name:</label>    
													<input type = "text" name = "lname" value = "" required/>   
												
											</div>    
											
											<div class = "form_group">    
											
												<label>Password:</label>    
													<input type = "password" name = "pwd" value = "" required/>    
												
												
												 <button type="submit" name="insert">&nbsp;Sign in</button>
					 
<?php


if (isset($_POST['insert'])) {

   //variables
  $firstname = $_POST['fname'];
  $middlename = $_POST['mname'];
  $lastname = $_POST['lname'];
  $password = $_POST['pwd'];



		// Insert Data
        $query = mysqli_query($conn , "INSERT INTO login (First_name, Middle_name, Last_name, Password)
        VALUES ('$firstname', '$middlename', '$lastname', '$password')") or die(mysqli_error());
       
		
			

}




?>
                                                                
                </div>    
            </div>    
        </form>    
    </body>    
</html>    