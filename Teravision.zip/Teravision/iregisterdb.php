<?php

    
    if (isset($_POST['submit'])) {
    //variables
    $username = $_POST['username'];
    $password = $_POST['password'];
    // Insert Data
    $query = mysqli_query($conn , "INSERT INTO register (Username, Password_in)
    VALUES ('$username', '$password')") or die(mysqli_error());       				
    }
?>