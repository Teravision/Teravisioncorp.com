<!DOCTYPE html>
<html>
<body>

<h2>JavaScript setFullYear()</h2>

<p>The setFullYear() method sets the year of a date object:</p>

<p id="demo"></p>

<script>
var d = new Date();
d.setFullYear(2020);
document.getElementById("demo").innerHTML = d;
</script>

</body>

<!-- Mirrored from www.w3schools.com/js/tryit.asp?filename=tryjs_date_setfullyear by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Jul 2018 01:53:33 GMT -->
</html>
